peliculas = []
cartelera = []
def leer_opcion():
    try:
        opcion_str = input("Seleccione una opción (1-6): ")
        opcion = int(opcion_str)
        if 1 <= opcion <= 6:
            return opcion
        else:
            return -1
    except ValueError:
        return -1

#Opcion 1: Cupos por genero
def cupos_genero(genero):
    total_cupos = 0
    genero_buscado = genero.lower()
    
    for cod, datos in peliculas.items():
        genero_pelicula = datos[1].lower()
        if genero_pelicula == genero_buscado:
            if cod in cartelera:
                total_cupos += cartelera[cod][1]
                
    print(f"\nTotal de cupos disponibles para el género '{genero}': {total_cupos}")

#Opcion 2: Busqueda de peliculas por rango de precio

def busqueda_precio(p_min, p_max):
    if p_min < 0 or p_max < 0 or p_min > p_max:
        print("Error: Los precios deben ser mayores o iguales a cero y p_min <= p_max.")
        return

    resultados = []
    for cod, datos_cartelera in cartelera.items():
        precio = datos_cartelera[0]
        cupos = datos_cartelera[1]
        
        if p_min <= precio <= p_max and cupos > 0:
            if cod in peliculas:
                titulo = peliculas[cod][0]
                resultados.append(f"{titulo}--{cod}")
                
    if len(resultados) == 0:
        print("No hay películas en ese rango de precios.")
    else:
        resultados.sort()
        print("\nPelículas encontradas:")
        for item in resultados:
            print(item)

#Opcion 3: Actualizar precio de pelicula
def buscar_codigo(codigo):
    codigo_upper = codigo.upper()
    for cod in cartelera.keys():
        if cod.upper() == codigo_upper:
            return True
    return False

def obtener_clave_real(codigo):
    codigo_upper = codigo.upper()
    for cod in cartelera.keys():
        if cod.upper() == codigo_upper:
            return cod
    return codigo

def actualizar_precio(codigo, nuevo_precio):
    if buscar_codigo(codigo):
        clave_real = obtener_clave_real(codigo)
        cartelera[clave_real][0] = nuevo_precio
        return True
    return False

# Opcion 4 : Agregar pelicula
def validar_codigo(codigo):
    if not codigo or codigo.isspace():
        return False
    if buscar_codigo(codigo):
        return False
    return True

def validar_titulo(titulo):
    return bool(titulo and not titulo.isspace())

def validar_genero(genero):
    return bool(genero and not genero.isspace())

def validar_duracion(duracion):
    return duracion > 0

def validar_clasificacion(clasificacion):
    return clasificacion in ['A', 'B', 'C']

def validar_idioma(idioma):
    return bool(idioma and not idioma.isspace())

def validar_es_3d(es_3d):
    return es_3d in ['s', 'n']

def validar_precio(precio):
    return precio > 0

def validar_cupos(cupos):
    return cupos >= 0

def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos):
    if buscar_codigo(codigo):
        return False
    
    codigo_upper = codigo.upper()
    valor_3d = True if es_3d == 's' else False
    peliculas[codigo_upper] = [titulo, genero, duracion, clasificacion, idioma, valor_3d]
    cartelera[codigo_upper] = [precio, cupos]
    return True

#Opcion 5: Eliminar pelicula
def eliminar_pelicula(codigo):
    if buscar_codigo(codigo):
        clave_real = obtener_clave_real(codigo)
        del peliculas[clave_real]
        del cartelera[clave_real]
        return True
    return False

def main():
    while True:
        print("========MENÚ PRINCIPAL========")
        print("1. Cupos por género")
        print("2. Búsqueda de películas por rango de precio")
        print("3. Actualizar precio de película")
        print("4. Agregar película")
        print("5. Eliminar película")
        print("6. Salir")
        
        opc = leer_opcion()
        
        if opc == -1:
            print("Debe seleccionar una opción válida")
            continue
            
        if opc == 1:
            gen = input("Ingrese el género a buscar: ")
            cupos_genero(gen)
            
        elif opc == 2:
            while True:
                try:
                    p_min = int(input("Ingrese el precio mínimo: "))
                    p_max = int(input("Ingrese el precio máximo: "))
                    break
                except ValueError:
                    print("Debe ingresar valores enteros")
            busqueda_precio(p_min, p_max)
            
        elif opc == 3:
            while True:
                cod = input("Ingrese el código de la película: ")
                try:
                    nuevo_p = int(input("Ingrese el nuevo precio: "))
                    if nuevo_p <= 0:
                        print("El precio debe ser un valor entero positivo.")
                        continue
                except ValueError:
                    print("Debe ingresar un valor entero para el precio.")
                    continue
                
                if actualizar_precio(cod, nuevo_p):
                    print("Precio actualizado")
                else:
                    print("El código no existe")
                    
                resp = input("¿Desea actualizar otro precio (s/n)?: ").lower()
                if resp != 's':
                    break
                    
        elif opc == 4:
            print("\n--- Registrar Nueva Película ---")
            cod = input("Código: ")
            if not validar_codigo(cod):
                print("Error: Código vacío o ya existente en el sistema.")
                continue
                
            tit = input("Título: ")
            if not validar_titulo(tit):
                print("Error: Título inválido.")
                continue
                
            gen = input("Género: ")
            if not validar_genero(gen):
                print("Error: Género inválido.")
                continue
                
            try:
                dur = int(input("Duración en minutos: "))
                if not validar_duracion(dur):
                    print("Error: La duración debe ser mayor que cero.")
                    continue
            except ValueError:
                print("Error: La duración debe ser un número entero.")
                continue
                
            clas = input("Clasificación (A/B/C): ")
            if not validar_clasificacion(clas):
                print("Error: Clasificación debe ser exactamente 'A', 'B' o 'C'.")
                continue
                
            idi = input("Idioma: ")
            if not validar_idioma(idi):
                print("Error: Idioma inválido.")
                continue
                
            e_3d = input("¿Es 3D? (s/n): ").lower()
            if not validar_es_3d(e_3d):
                print("Error: Debe ingresar únicamente 's' o 'n'.")
                continue
                
            try:
                prec = int(input("Precio: "))
                if not validar_precio(prec):
                    print("Error: El precio debe ser un número entero mayor que cero.")
                    continue
            except ValueError:
                print("Error: El precio debe ser un número entero.")
                continue
                
            try:
                cup = int(input("Cupos: "))
                if not validar_cupos(cup):
                    print("Error: Los cupos deben ser mayores o iguales a cero.")
                    continue
            except ValueError:
                print("Error: Los cupos deben ser un número entero.")
                continue
            if agregar_pelicula(cod, tit, gen, dur, clas, idi, e_3d, prec, cup):
                print("Película agregada")
            else:
                print("El código ya existe")
                
        elif opc == 5:
            cod = input("Ingrese el código de la película a eliminar: ")
            if eliminar_pelicula(cod):
                print("Película eliminada")
            else:
                print("El código no existe")
                
        elif opc == 6:
            print("Programa finalizado.")
            break

if __name__ == "__main__":
    main()